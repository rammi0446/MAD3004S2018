//
//  Protocols.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
// protocol known as interface
protocol IDisplay {
    func displayData() -> String
    
  
}
public protocol CaseIterable {
    associatedtype AllCases: Collection where AllCases.Element == Self
    static var allCases: AllCases { get }
}

protocol EmployeeInfo{
    
    //MARK:- Variables
    
    var employeeID : Int{get set}
    var employeeName : String{get set}
    var employeeEmail: String{get set}
    var employeeMobile: Int{get set}
    var employeeAddress: String{get set}
    var employeeDesignation: String{get set}
    var employeeSinNumber: String{get set}
    
    func addEmployee()
//    func addEmployee(){
//    print("Enter employee ID : ")
//    self.employeeID = readLine()!
//    print("Enter employeeName : ")
//    self.employeeName = readLine()!
//    print("Enter employeeEmail  : ")
//    self.employeeEmail = readLine()!
//    print("Enter employeeMobile : ")
//    self.employeeMobile = readLine()!
//    print("Enter employeeAddress : ")
//    self.employeeAddress = readLine()!
//    print("Enter employeeDesignation : ")
//    self.employeeDesignation = readLine()!
//    print("Enter employeeSinNumber : ")
//    self.employeeSinNumber = readLine()!
//    }
    init()
    
    init(employeeID: Int, employeeName : String, employeeEmail: String, employeeMobile: Int, employeeAddress: String, employeeDesignation: String )
    
}

//MARK:- Protocols

protocol  PassengerInfo {
    
    var passengerId : String{get set}
    var passengerPassportNumber : String{get set}
    var passengerName : String{get set}
    var passengerMobile : Int{get set}
    var passengerEmail : String{get set}
    var passengerAddress : String{get set}
    
    func addPassenger()
    
}

protocol  FlightInfo {
    
    var flightId : Int{get set}
    var flightTo : String{get set}
    var flightFrom : String{get set}
    //var flightScheduleDate : Date{get set}
    var flightAirlineId : Int{get set}
    var flightAirplaneId : Int{get set}
    var flightPilotId : Int{get set}
    
    func addFlight()
    //    func addFlight(){
    //    print("Enter flight Id  : ")
    //    self.flightId = readLine()!
    //    print("Enter flightTo : ")
    //    self.flightTo = readLine()!
    //    print("Enter flightFrom  : ")
    //    self.flightFrom = readLine()!
    //    print("Enter flightAirlineId : ")
    //    self.flightAirlineId = readLine()!
    //    print("Enter flightAirplaneId : ")
    //    self.flightAirplaneId = readLine()!
    //    print("Enter flightPilotId : ")
    //    self.flightPilotId = readLine()!
    //    }
    init()
    
    init(flightId: Int, flightTo : String, flightFrom: String, flightAirlineId: Int, flightAirplaneId: Int, flightPilotId: Int )
}
