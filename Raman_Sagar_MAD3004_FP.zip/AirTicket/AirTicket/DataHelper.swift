//
//  DataHelper.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper{
    var FlightList = [Int : Flight]()
    
    init(){
        self.loadFlightsData()
    }
    
    //MARK:- Loading flight data
    
    func loadFlightsData(){
        FlightList = [:]
        
        do{
            
            let first = try Flight(flightID: 111, flightTo: "Toronto", flightFrom: "India", flightAirlineId: 1000, flightAirplaneId: 22, flightPilotId: 44 , price: 2000, totalSeats: 100)
            FlightList[(first.flightID!)] = first
            
            let second = try Flight(flightID: 112, flightTo: "London", flightFrom: "India", flightAirlineId: 1001, flightAirplaneId: 23, flightPilotId: 45, price: 3000,totalSeats: 50 )
            FlightList[(second.flightID!)] = second
            
            let third = try Flight(flightID: 113, flightTo: "UK", flightFrom: "Toronto", flightAirlineId: 1003, flightAirplaneId: 24, flightPilotId: 46, price: 4000, totalSeats: 120)
            FlightList[(third.flightID!)] = third
            
            let forth = try Flight(flightID: 114, flightTo: "CANADA", flightFrom: "USA", flightAirlineId: 1004, flightAirplaneId: 25, flightPilotId: 45, price: 3000,totalSeats: 50)
            FlightList[(forth.flightID!)] = forth
            
            let fifth = try Flight(flightID: 115, flightTo: "USA", flightFrom: "UK", flightAirlineId: 1005, flightAirplaneId: 26, flightPilotId: 46, price: 4000,totalSeats: 70 )
            FlightList[(fifth.flightID!)] = fifth
            
        }catch{
            print("Error: \(error)")
        }
    }

    //MARK:- Displaying data
    
    func displayLists(){
        print("Flight Details")
        Util.drawLine()
        print("\t Flight ID \t\t Flight From \t\t Flight To \t\t\t\t TotalSeats ")
        for (_, value) in self.FlightList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
         print("\t \(value.flightID!) ------------- \(value.flightFrom!) ------ ------\(value.flightTo!) ------------------\(value.totalSeats!)")
        }
        Util.drawLine()
    }
    
    //MARK:- Searching list
    
    func searchList(flightID : Int) -> Flight?{
        if FlightList[flightID] != nil{
            return FlightList[flightID]! as Flight
        }
        else{
            print("Sorry..The Flight number you have entered is not available")
            return nil
        }
    }
   
}
