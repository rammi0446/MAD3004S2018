//
//  planeType.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class PlaneType {
    
    //MARK:- Variables
    
    var planeTypeID : Int?
    var planeTypeTotalSeats : String?
//    var planeTypeSeatMap : CGVector?
    
    var dictPlaneType : [Int : String] = [1 : "100" , 2 : "140" , 3 : "200"]
    
    var PlaneTypeID : Int? {
        get {
            return self.PlaneTypeID
        }
        set {
            self.PlaneTypeID = newValue
        }
    }
    
    var PlaneTypeTotalSeats : String? {
        get {
            return self.PlaneTypeTotalSeats
        }
        set {
            self.PlaneTypeTotalSeats = newValue
        }
    }
    
    var PlaneTypeSeatMap : CGVector? {
        get {
            return self.PlaneTypeSeatMap
        }
        set {
            self.PlaneTypeSeatMap = newValue
        }
    }
    
    //MARK:- Initialising variables
    
    init() {
        self.planeTypeID = 0
        self.planeTypeTotalSeats = ""
      //  self.planeTypeSeatMap = 0
    }
    
    init(planeTypeID: Int,planeTypeTotalSeats: String)
    {
        self.planeTypeID = planeTypeID
        self.planeTypeTotalSeats = planeTypeTotalSeats
    }
    
    //MARK:- Displaying data
    
    func displayData() -> String {
        var returnData = ""
        
        if PlaneTypeID != nil {
            returnData += "Plane type id : " + String(self.planeTypeID!)
        }
        if PlaneTypeTotalSeats != nil {
            returnData += "Total seats : " + String(self.planeTypeTotalSeats!)
        }
//        if PlaneTypeSeatMap != nil {
//            returnData += "Seat Map : " + String(self.planeTypeSeatMap!)
//        }
        return returnData
    }
}
