//
//  main.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

//MARK:- Variables

var choice = Int()
var can = String()
var dataHelper = DataHelper()
var reservation = Reservation()
var res = Reservation()

while choice != 6{
    print("\n----What would you like to do today !----")
    print("\t 1 : Display List ")
    print("\t 2 : Add Passenger ")
    print("\t 3 : Show Booking ")
    print("\t 4 : Cancel Booking ")
    print("\t 5 : Update Booking ")
    print("\t 6 : Exit ")
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = Int(readLine()!)!
    
    //MARK:- Switch case for choice
    
    if choice == 0 {
        choice = 1
    } else {
        switch choice{
        case 1:
            dataHelper.displayLists()
        case 2:
            print("ENTER PASSENGER DETAILS \n")
            res.addPassenger()
            print("\nENTER RESERVATION DETAILS \n")
            res.addReservation()
        case 3:
            print(res.displayData())
            switch savedFlightId{
            case 111:
                print(" Flight id : 111 \n" + " Flight From : India \n" + " Flight To : Toronto \n  " )
                print("Total Price : $\(NumberOfTickets! * 2000)")
            case 112:
                print(" Flight id : 112 \n" + " Flight From : India \n" + " Flight To : London \n " + "Total Price : $\(NumberOfTickets! * 3000)" )
            case 113:
                print(" Flight id : 113 \n" + " Flight From : Toronto \n" + " Flight To : UK \n "  + "Total Price : $\(NumberOfTickets! * 4000)")
            case 114:
                print(" Flight id : 114 \n" + " Flight From : USA \n" + " Flight To : Canada \n " + "Total Price : $\(NumberOfTickets! * 800)")
            case 115:
                print(" Flight id : 115 \n" + " Flight From : UK \n" + " Flight To : USA \n " + "Total Price : $\(NumberOfTickets! * 4000)")
            default:
                print("Flight Id Unavailable")
            }
        case 4:
            savedFlightId = nil
            if savedFlightId != nil {
                print(res.displayData())
            }
            else{
                print("\n Flight is successfully cancelled")
            }
        case 5:
            
            if savedFlightId == nil {
                print("\n No bookings to update")
            } else {
                savedFlightId = nil
                print("ENTER PASSENGER DETAILS \n")
                res.addPassenger()
                print("\nENTER RESERVATION DETAILS \n")
                res.addReservation()
            }
        case 6:
            exit(0)
        default:
            print("Please enter valid menu option.")
        }
    }
    
    
    
}



