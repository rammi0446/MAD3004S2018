//
//  Reservation.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var savedFlightId : Int?
var NumberOfTickets : Int?
//typealias flightItem = (flightID: Int, flight: Flight, quantity: Int )

class Reservation : Flight, PassengerInfo  {
    
    //MARK:- Variables
    
    var passengerId: String
    var passengerPassportNumber: String
    var passengerName: String
    var passengerMobile: Int
    var passengerEmail: String
    var passengerAddress: String
    
    
    var resID : Int?
    var resDesc : String?
    var resFlightId : Int?
    var resSeatNumber : String?
    var resStatus : ResStatusList?
    var resMealType : String?
    var resNumberOfTickets : Int?
  
    var ResID : Int?
    {
        get{  return self.resID}
        set{self.resID = newValue}
    }
    var ResNumberOfTickets: Int?
    {
        get{  return self.resNumberOfTickets}
        set{self.resNumberOfTickets = newValue}
    }
    var ResDesc : String?
    {
        get{return self.resDesc}
        set{self.resDesc = newValue}
    }
    var PassengerId : String?
    {
        get{return self.passengerId}
        set{self.passengerId = (newValue)!}
    }
    var ResFlightId : Int?
    {
        get{return self.resFlightId}
        set{self.resFlightId = newValue}
    }

    var ResSeatNumber : String?
    {
        get{ return self.resSeatNumber}
        set{self.resSeatNumber = newValue}
    }
    var ResStatus : ResStatusList?{
        get { return self.resStatus ?? ResStatusList.NoOrder }
        set{ self.resStatus = newValue}
    }
    var ResMealType : String?
    {
        get{return self.resMealType}
        set{ self.resMealType = newValue}
    }
    
    // MARK:- Initializer
    
    override required init() {
       
        self.resID = 0
        self.resDesc = ""
        self.resNumberOfTickets = 0
        self.passengerId = ""
        self.resFlightId = 0
        self.resSeatNumber = ""
        self.resStatus = ResStatusList.NoOrder
        self.resMealType = ""
        self.passengerId = ""
        self.passengerPassportNumber = ""
        self.passengerName = ""
        self.passengerMobile = 0
        self.passengerEmail = ""
        self.passengerAddress = ""
        super.init()
    }
    
   
    required init(flightID: Int, flightTo: String, flightFrom: String, flightAirlineId: Int, flightAirplaneId: Int, flightPilotId:  Int, price : Int, totalSeats: Int, passengerId : String, passengerPassportNumber: String, passengerName: String, passengerMobile: Int,  passengerEmail: String, passengerAddress: String,resID: Int, resDesc : String, resFlightId : Int, resSeatNumber : String, resStatus: String, resMealType: String, resNumberOfTickets: Int) {
        
        self.passengerId = passengerId
        self.passengerPassportNumber = passengerPassportNumber
        self.passengerName = passengerName
        self.passengerMobile = passengerMobile
        self.passengerEmail = passengerEmail
        self.passengerAddress = passengerAddress
        self.resID = resID
        self.resDesc = resDesc
        self.resFlightId = resFlightId
        self.resSeatNumber = resSeatNumber
        self.resMealType = resMealType
        self.resNumberOfTickets = resNumberOfTickets
        
        super.init(flightID: flightID, flightTo: flightTo, flightFrom: flightFrom, flightAirlineId: flightAirlineId, flightAirplaneId: flightAirplaneId, flightPilotId: flightPilotId, price: price, totalSeats: totalSeats)
    }
    
    //MARK:- Adding passengers
    
        func addPassenger(){
            print("Enter passenger Id  : ")
            self.passengerId = readLine()!
            print("Enter passenger Passport Number : ")
            self.passengerPassportNumber = readLine()!
            print("Enter passenger Name  : ")
            self.passengerName = readLine()!
            print("Enter passenger Mobile : ")
            self.passengerMobile = Int(readLine()!)!
            print("Enter passenger Email : ")
            self.passengerEmail = readLine()!
            print("Enter passenger Address : ")
            self.passengerAddress = readLine()!
            print("enter flight id you want to select :")
            self.resFlightId = Int(readLine()!)
            
            savedFlightId = resFlightId
        }
    
    //MARK:- Adding reservation

    func addReservation(){
        
        print("Enter SeatNumber : ")
         self.resSeatNumber = readLine()!
       
        print("Enter MealType : ")
        self.resMealType = readLine()!
        
        print("enter total number of tickets")
        self.resNumberOfTickets = Int(readLine()!)
        NumberOfTickets = resNumberOfTickets
        
    }
    
    //MARK:- Displaying data
    
    override func displayData() -> String {
        var returnData = ""
        if savedFlightId == nil {
            print("\n No bookings yet")
        } else {
            if self.ResSeatNumber != nil {returnData += "\n Seat Number: " + String(self.resSeatNumber!)}
            if self.ResMealType != nil {returnData += "\n Meal Type : " + self.resMealType!}
            if self.PassengerId != nil {returnData += "\n Passenger Id : " + String(self.passengerId)}
            if self.passengerName != nil {returnData += "\n Passenger Name  : " + self.passengerName}
            if self.passengerAddress != nil {returnData += "\n Passenger Address : " + self.passengerAddress}
            if self.passengerPassportNumber != nil {returnData += "\n passenger Passport Number: " + String(self.passengerPassportNumber)}
            if self.passengerMobile != nil {returnData += "\n passenger Mobile: " + String(self.passengerMobile)}
            if self.passengerEmail != nil {returnData += "\n passenger Email Address: " + String(self.passengerEmail)}
            
        }
        return returnData
    }
    
    
}
