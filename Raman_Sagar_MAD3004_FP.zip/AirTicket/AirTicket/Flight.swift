//
//  Flight.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Flight : IDisplay {
    
    //MARK:- Variables
    
    var flightID : Int?
    var flightTo : String?
    var flightFrom : String?
    var flightScheduleDate : Date?
    var flightAirlineId : Int?
    var flightAirplaneId : Int?
    var flightPilotId : Int?
    var price : Int?
    var totalSeats : Int?
    
    var FlightID : Int? {
        get {
            return self.flightID
        }
        set {
            self.flightID = newValue
        }
    }
    
    var FlightTo : String? {
        get {
            return self.flightTo
        }
        set {
            self.flightTo = newValue
        }
    }
    
    var Price : Int? {
        get {
            return self.price
        }
        set {
            self.price = newValue
        }
    }
    var TotalSeats : Int? {
        get {
            return self.totalSeats
        }
        set {
            self.totalSeats = newValue
        }
    }
    var FlightFrom : String? {
        get {
            return self.flightFrom
        }
        set {
            self.flightFrom = newValue
        }
    }
    
    var FlightScheduleDate : Date? {
        get {
            return self.flightScheduleDate
        }
        set {
            self.FlightScheduleDate = newValue
        }
    }
    
    var FlightAirlineId : Int? {
        get {
            return self.flightAirlineId
        }
        set {
            self.flightAirlineId = newValue
        }
    }
    
    var FlightAirplaneId : Int? {
        get {
            return self.flightAirplaneId
        }
        set {
            self.flightAirplaneId = newValue
        }
    }
    var FlightPilotId : Int? {
        get {
            return self.flightPilotId
        }
        set {
            self.flightPilotId = newValue
        }
    }
    
    //MARK:- Initialising variables
    
    init() {
        self.flightTo = ""
        self.flightFrom = ""
        self.flightID = 0
        self.flightAirlineId = 0
        self.flightAirplaneId = 0
        self.flightPilotId = 0
        self.price = 0
        self.totalSeats = 0
    }
    
    init(flightID : Int, flightTo : String, flightFrom : String, flightAirlineId : Int, flightAirplaneId : Int, flightPilotId : Int, price : Int, totalSeats : Int) {
        
        self.flightID = flightID
        self.flightTo = flightTo
        self.flightFrom = flightFrom
        self.flightAirlineId = flightAirlineId
        self.flightAirplaneId = flightAirplaneId
        self.flightPilotId = flightPilotId
        self.price = price
        self.totalSeats = totalSeats
        
    }
    
    //MARK:- Adding flights
    
    func addFlight(){
            print("Enter flight Id  : ")
            self.flightID = Int(readLine()!)
            print("Enter flightTo : ")
            self.flightTo = readLine()!
            print("Enter flightFrom  : ")
            self.flightFrom = readLine()!
            print("Enter flightAirlineId : ")
            self.flightAirlineId = Int(readLine()!)
            print("Enter flightAirplaneId : ")
            self.flightAirplaneId = Int(readLine()!)
            print("Enter flightPilotId : ")
            self.flightPilotId = Int(readLine()!)
            print("Enter price : ")
            self.price = Int(readLine()!)
            }
    
    // MARK:- Function to display data
    
    func displayData() -> String {
        
        var returnData = ""
        
        if self.flightID != nil {
            returnData += "\n Flight Id : " + String(self.flightID!)
        }
        if self.flightTo != nil {
            returnData += "\n Flight To : " + self.flightTo!
        }
        if self.flightFrom != nil {
            returnData += "\n Flight From : " + self.flightFrom!
        }

        if self.flightAirlineId != nil {
            returnData += "\n Flight Airline Id: " + String(self.flightAirlineId!)
        }
        if self.flightAirplaneId != nil {
            returnData += "\n Flight Airplane Id: " + String(self.flightAirplaneId!)
        }
        if self.flightPilotId != nil {
            returnData += "\n Flight pilot Id : " + String(self.flightPilotId!)
        }
        if self.price != nil {
            returnData += "\n Price : " + String(self.price!)
        }
        if self.totalSeats != nil {
            returnData += "\n Total Seats : " + String(self.totalSeats!)
        }
        return returnData
        
    }
    
}
