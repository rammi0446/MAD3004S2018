//
//  Reservation.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Reservation : Flight, PassengerInfo  {
    var passengerId: Int
    
    var passengerPassportNumber: String
    
    var passengerName: String
    
    var passengerMobile: Int
    
    var passengerEmail: String
    
    var passengerAddress: String
    
    
    
    var resID : Int?
    var resDesc : String?
    var resFlightId : Int?
    var resSeatNumber : String?
    var resStatus : String?
    var resMealType : String?
    
    var ResID : Int?
    {
        get
        {
            return self.resID
        }
        set
        {
            self.resID = newValue
        }
    }
    var ResDesc : String?
    {
        get
        {
            return self.resDesc
        }
        set
        {
            self.resDesc = newValue
        }
    }
    var PassengerId : Int?
    {
        get
        {
            return self.passengerId
        }
        set
        {
            self.passengerId = (newValue)!
        }
    }
    var ResFlightId : Int?
    {
        get
        {
            return self.resFlightId
        }
        set
        {
            self.resFlightId = newValue
        }
    }

    var ResSeatNumber : String?
    {
        get
        {
            return self.resSeatNumber
        }
        set
        {
            self.resSeatNumber = newValue
        }
    }
    var ResStatus : String?
    {
        get
        {
            return self.resStatus
        }
        set
        {
            self.resStatus = newValue
        }
    }
    var ResMealType : String?
    {
        get
        {
            return self.resMealType
        }
        set
        {
            self.resMealType = newValue
        }
    }
    
    
    override required init() {
       
        self.resID = 0
        self.resDesc = ""
        self.passengerId = 0
        self.resFlightId = 0
        self.resSeatNumber = ""
        self.resStatus = ""
        self.resMealType = ""
        self.passengerId = 0
        self.passengerPassportNumber = ""
        self.passengerName = ""
        self.passengerMobile = 0
        self.passengerEmail = ""
        self.passengerAddress = ""
        super.init()
    }
    
   
    
    required init(flightID: Int, flightTo: String, flightFrom: String, flightAirlineId: Int, flightAirplaneId: Int, flightPilotId:  Int, passengerId : Int, passengerPassportNumber: String, passengerName: String, passengerMobile: Int,  passengerEmail: String, passengerAddress: String,resID: Int, resDesc : String, resFlightId : Int, resSeatNumber : String, resStatus: String, resMealType: String) {
        
        self.passengerId = passengerId
        self.passengerPassportNumber = passengerPassportNumber
        self.passengerName = passengerName
        self.passengerMobile = passengerMobile
        self.passengerEmail = passengerEmail
        self.passengerAddress = passengerAddress
        self.resID = resID
        self.resDesc = resDesc
        self.resFlightId = resFlightId
        self.resSeatNumber = resSeatNumber
        self.resStatus = resStatus
        self.resMealType = resMealType
        
        super.init(flightID: flightID, flightTo: flightTo, flightFrom: flightFrom, flightAirlineId: flightAirlineId, flightAirplaneId: flightAirplaneId, flightPilotId: flightPilotId)
    }
    
    func addPassenger(){
        print("Enter passenger Id  : ")
        self.passengerId = Int(readLine()!)!
        print("Enter passenger Passport Number : ")
        self.passengerPassportNumber = readLine()!
        print("Enter passenger Name  : ")
        self.passengerName = readLine()!
        print("Enter passenger Mobile : ")
        self.passengerMobile = Int(readLine()!)!
        print("Enter passenger Email : ")
        self.passengerEmail = readLine()!
        print("Enter passenger Address : ")
        self.passengerAddress = readLine()!
    }
    
    func addReservation(){
        print("Enter resID  : ")
         self.resID = Int(readLine()!)
        print("Enter resDesc : ")
        self.resDesc = readLine()!
        //print("Enter resFlightId  : ")
       // self.resFlightId = Int(readLine()!)
        print("Enter resSeatNumber : ")
         self.resSeatNumber = readLine()!
        print("Enter resStatus : ")
        self.resStatus = readLine()!
        print("Enter resMealType : ")
        self.resMealType = readLine()!
    }
    override func displayData() -> String {
        
        var returnData = ""
        
        if self.ResID != nil {
            returnData += "\n reservation ID : " + String(self.resID!)
        }
        if self.ResDesc != nil {
            returnData += "\n reservation Desc : " + self.resDesc!
        }
        if self.PassengerId != nil {
            returnData += "\n Passenger Id : " + String(self.passengerId)
        }
       
        if self.ResFlightId != nil {
            returnData += "\n Flight Id: " + String(self.flightID!)
        }
        if self.ResSeatNumber != nil {
            returnData += "\n reservation Seat Number: " + String(self.resSeatNumber!)
        }
        if self.ResMealType != nil {
            returnData += "\n reservation Meal Type : " + self.resMealType!
        }
        
        return returnData
        
    }
    
    
}
