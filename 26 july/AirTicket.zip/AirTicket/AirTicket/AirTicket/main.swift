//
//  main.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


//var passenger = Passenger(passengerId: 1, passengerPassportNumber: "549785614231", passengerName: "Sagar", PassengerMobile: 68765435354, PassengerEmail: "Sagar@gmail.com", PassengerAddress: "5 Banting" )
//print(passenger.displayData())
//
//var flight = Flight(flightId: 101, flightTo: "India", flightFrom: "Canada",/* flightScheduleDate: <#T##Date#>,*/ flightAirlineId: 40, flightAirplaneId: 50, flightPilotId: 20)
//print(flight.displayData())
//
//var employee = Employee(employeeID: 11, employeeName: "raman", employeeEmail: "raman@gmail.com", employeeMobile: 546546435, employeeAdress: "Toronto", employeeDesignation: "MD", employeeSinNumber: "a54568")
//print(employee.displayData())
//
//var reservation = Reservation(resID: 9, resDesc: "hfjgd", resPassengerId: 1, resFlightId: 101, resSeatNumber: "34", resStatus: "confirm", resMealType: "veg")
//print(reservation.displayData())

var res = Reservation()
print("ENTER PASSENGER DETAILS \n")
res.addPassenger()
print("\nENTER RESERVATION DETAILS \n")
res.addReservation()
print("\nENTER FLIGHT DETAILS \n ")
res.addFlight()
print(res.displayData())


