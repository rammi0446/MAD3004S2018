//
//  DataHelper.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper{
    var FlightList = [Int : Flight]()
   // var PassengerList = [String : Passenger]()
    
    init(){
        self.loadFlightsData()
       // self.loadPassengersData()
    }
    
    func loadFlightsData(){
        FlightList = [:]
        
        do{
            
            let first = try Flight(flightID: 111, flightTo: "A", flightFrom: "B", flightAirlineId: 1000, flightAirplaneId: 22, flightPilotId: 44 , price: 2000)
            FlightList[(first.flightID!)] = first
            
            let second = try Flight(flightID: 112, flightTo: "E", flightFrom: "R", flightAirlineId: 1001, flightAirplaneId: 23, flightPilotId: 45, price: 3000 )
            FlightList[(second.flightID!)] = second
            
            let third = try Flight(flightID: 113, flightTo: "F", flightFrom: "T", flightAirlineId: 1003, flightAirplaneId: 24, flightPilotId: 46, price: 4000 )
            FlightList[(third.flightID!)] = third
            
            
        }catch{
            print("Error: \(error)")
        }
    }
    
    func displayLists(){
        print("Flight Details")
        Util.drawLine()
        print("\t Flight ID \t\t Flight From \t\t\t\t Flight To ")
        for (_, value) in self.FlightList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
         print("\t \(value.flightID!) ------ \(value.flightFrom!) ------ \(value.flightTo!)")
        }
        Util.drawLine()
    }
    
    func searchList(flightID : Int) -> Flight?{
        if FlightList[flightID] != nil{
            return FlightList[flightID]! as Flight
        }
        else{
            print("Sorry..The Flight number you have entered is not available")
            return nil
        }
    }
   
//    func loadPassengersData(){
//        PassengerList = [:]
//
//        let Param = Passenger(passengerId: "101", passengerPassportNumber: "P101", passengerName: "param", PassengerMobile: 364654231, PassengerEmail: "param@gmail.com", PassengerAddress: "Brampton")
//        PassengerList[Param.passengerId!] = Param
//
//        let Santosh = Passenger(passengerId: "102", passengerPassportNumber: "P102", passengerName: "Sagar", PassengerMobile: 874654231, PassengerEmail: "Sagar@gmail.com", PassengerAddress: "Toronto")
//        PassengerList[Santosh.passengerId!] = Santosh
//    }
//
//    func displayPassengers(){
//        for (_, value) in self.PassengerList.sorted(by: { $0.key < $1.key }){
//            Util.drawLine()
//            print(value.displayData())
//        }
//        Util.drawLine()
//    }
}
