//
//  main.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


//var passenger = Passenger(passengerId: 1, passengerPassportNumber: "549785614231", passengerName: "Sagar", PassengerMobile: 68765435354, PassengerEmail: "Sagar@gmail.com", PassengerAddress: "5 Banting" )
//print(passenger.displayData())
//
//var flight = Flight(flightId: 101, flightTo: "India", flightFrom: "Canada",/* flightScheduleDate: <#T##Date#>,*/ flightAirlineId: 40, flightAirplaneId: 50, flightPilotId: 20)
//print(flight.displayData())
//
//var employee = Employee(employeeID: 11, employeeName: "raman", employeeEmail: "raman@gmail.com", employeeMobile: 546546435, employeeAdress: "Toronto", employeeDesignation: "MD", employeeSinNumber: "a54568")
//print(employee.displayData())
//
//var reservation = Reservation(resID: 9, resDesc: "hfjgd", resPassengerId: 1, resFlightId: 101, resSeatNumber: "34", resStatus: "confirm", resMealType: "veg")
//print(reservation.displayData())

 var res = Reservation()



var choice = 1
let dataHelper = DataHelper()
var reservation = Reservation()
while choice != 6{
    print("\n----What would you like to do today !----")
    print("\t 1 : Display List ")
    print("\t 2 : Add Passenger ")
    print("\t 3 : Show Booking ")
    print("\t 4 : Update Booking ")
    print("\t 5 : Cancel Booking ")
    print("\t 6 : Exit ")
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
    case 1:
        dataHelper.displayLists()
    case 2:
        print("ENTER PASSENGER DETAILS \n")
        res.addPassenger()
        print("\nENTER RESERVATION DETAILS \n")
        res.addReservation()
    case 3:
      print(res.displayData())
//        //    case 4:
//    //        order.updateOrder()
//    case 5:1
//       // order.cancelOrder()
    case 6:
        exit(0)
    default:
        print("Please enter valid menu option.")
    }
   
    
    
}



