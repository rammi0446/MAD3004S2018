//
//  Passenger.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class Passenger {
    
    var passengerId : String?
    var passengerPassportNumber : String?
    var passengerName : String?
    var passengerMobile : Int?
    var passengerEmail : String?
    var passengerAddress : String?
    var flightId : Int?
  
    
    
    var PassengerId : String? {
        get {
            return self.passengerId
        }
        set {
            self.passengerId = newValue
        }
    }
    
    var FlightId : Int? {
        get {
            return self.flightId
        }
        set {
            self.flightId = newValue
        }
    }
    var PassengerPassportNumber : String? {
        get {
            return self.passengerPassportNumber
        }
        set {
            self.passengerPassportNumber = newValue
        }
    }
    
    var PassengerName : String? {
        get {
            return self.passengerName
        }
        set {
            self.passengerName = newValue
        }
    }
    
    var PassengerMobile : Int? {
        get {
            return self.passengerMobile
        }
        set {
            self.passengerMobile = newValue
        }
    }
    
    var PassengerEmail : String? {
        get {
            return self.passengerEmail
        }
        set {
            self.passengerEmail = newValue
        }
    }
    
    var PassengerAddress : String? {
        get {
            return self.passengerAddress
        }
        set {
            self.passengerAddress = newValue
        }
    }

    init() {
        self.passengerId = ""
        self.passengerPassportNumber = ""
        self.passengerName = ""
        self.passengerMobile = 0
        self.passengerEmail = ""
        self.passengerAddress = ""
        
       // self.passengerBirthDate = 29-01-1992
    }
    
    init(passengerId: String,passengerPassportNumber: String,passengerName: String,PassengerMobile: Int,PassengerEmail: String, PassengerAddress: String)
    {
        self.passengerId = passengerId
        self.passengerPassportNumber = passengerPassportNumber
        self.passengerName = passengerName
        self.PassengerMobile = PassengerMobile
        self.passengerEmail = PassengerEmail
        
    }
//    func addPassenger(){
//        dataHelper.displayLists()
//        print("Please enter flight ID to choose any flight from the list : ")
//        let selectedFlightID : Int = (Int)(readLine()!)!
//        
//        if let selectedFlight = dataHelper.searchList(flightID: selectedFlightID){
//            self.flightId = selectedFlightID
//           // self.OrderDate = Date()
//            
//            print("How many tickets do you want ? : ")
//            let qty : Int = (Int)(readLine()!) ?? 1
//            
//            self.orderLists += [(flightId: selectedFlightID, flightTo: selectedFlight, quantity: qty)]
//            self.OrderStatus = OrderStatusList.Placed
//            
//        }else{
//            print("Sorry...The flight you entered is unavailable")
//        }
//        print("Enter passenger Id  : ")
//        self.passengerId = readLine()!
//        print("Enter passenger Passport Number : ")
//        self.passengerPassportNumber = readLine()!
//        print("Enter passenger Name  : ")
//        self.passengerName = readLine()!
//        print("Enter passenger Mobile : ")
//        self.passengerMobile = Int(readLine()!)!
//        print("Enter passenger Email : ")
//        self.passengerEmail = readLine()!
//        print("Enter passenger Address : ")
//        self.passengerAddress = readLine()!
//    }
//    
    func displayData() -> String {
        
        var returnData = ""
        
        if self.passengerId != nil {
            returnData += "\n Passenger Id : " + self.passengerId!
        }
        if self.passengerName != nil {
            returnData += "\n passengerName : " + self.passengerName!
        }
        if self.passengerPassportNumber != nil {
            returnData += "\n passengerPassportNumber : " + self.passengerPassportNumber!
        }
       
        if self.passengerMobile != nil {
            returnData += "\n passengerMobile: " + String(self.passengerMobile!)
        }
        if self.passengerEmail != nil {
            returnData += "\n passengerEmail: " + self.passengerEmail!
        }
        if self.passengerAddress != nil {
            returnData += "\n passengerAddress: " + String(self.passengerAddress!)
        }
        
        return returnData
        
    }
    
}
