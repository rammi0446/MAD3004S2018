//
//  Reservation.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

//typealias flightItem = (flightID: Int, flight: Flight, quantity: Int )

class Reservation : Flight, PassengerInfo  {
    
    
    
    var passengerId: String
    
    var passengerPassportNumber: String
    
    var passengerName: String
    
    var passengerMobile: Int
    
    var passengerEmail: String
    
    var passengerAddress: String
    
    
    
    var resID : Int?
    var resDesc : String?
    var resFlightId : Int?
    var resSeatNumber : String?
    var resStatus : ResStatusList?
    var resMealType : String?
    
  //  var orderLists: [flightItem]
    
    var ResID : Int?
    {
        get
        {
            return self.resID
        }
        set
        {
            self.resID = newValue
        }
    }
    var ResDesc : String?
    {
        get
        {
            return self.resDesc
        }
        set
        {
            self.resDesc = newValue
        }
    }
    var PassengerId : String?
    {
        get
        {
            return self.passengerId
        }
        set
        {
            self.passengerId = (newValue)!
        }
    }
    var ResFlightId : Int?
    {
        get
        {
            return self.resFlightId
        }
        set
        {
            self.resFlightId = newValue
        }
    }

    var ResSeatNumber : String?
    {
        get
        {
            return self.resSeatNumber
        }
        set
        {
            self.resSeatNumber = newValue
        }
    }
    var ResStatus : ResStatusList?{
        get { return self.resStatus ?? ResStatusList.NoOrder }
        set{ self.resStatus = newValue}
    }
    var ResMealType : String?
    {
        get
        {
            return self.resMealType
        }
        set
        {
            self.resMealType = newValue
        }
    }
    
    
    override required init() {
       
        self.resID = 0
        self.resDesc = ""
        self.passengerId = ""
        self.resFlightId = 0
        self.resSeatNumber = ""
        self.resStatus = ResStatusList.NoOrder
        self.resMealType = ""
        self.passengerId = ""
        self.passengerPassportNumber = ""
        self.passengerName = ""
        self.passengerMobile = 0
        self.passengerEmail = ""
        self.passengerAddress = ""
        super.init()
    }
    
   
    
    required init(flightID: Int, flightTo: String, flightFrom: String, flightAirlineId: Int, flightAirplaneId: Int, flightPilotId:  Int, price : Int, passengerId : String, passengerPassportNumber: String, passengerName: String, passengerMobile: Int,  passengerEmail: String, passengerAddress: String,resID: Int, resDesc : String, resFlightId : Int, resSeatNumber : String, resStatus: String, resMealType: String) {
        
        self.passengerId = passengerId
        self.passengerPassportNumber = passengerPassportNumber
        self.passengerName = passengerName
        self.passengerMobile = passengerMobile
        self.passengerEmail = passengerEmail
        self.passengerAddress = passengerAddress
        self.resID = resID
        self.resDesc = resDesc
        self.resFlightId = resFlightId
        self.resSeatNumber = resSeatNumber
       
        self.resMealType = resMealType
        
        super.init(flightID: flightID, flightTo: flightTo, flightFrom: flightFrom, flightAirlineId: flightAirlineId, flightAirplaneId: flightAirplaneId, flightPilotId: flightPilotId, price: price)
    }
    
        func addPassenger(){
//            dataHelper.displayLists()
//            print("Please enter flight ID to choose any flight from the list : ")
//            let selectedFlightID : Int = (Int)(readLine()!)!
//
//            if let selectedFlight = dataHelper.searchList(flightID: selectedFlightID){
//                self.resFlightId = selectedFlightID
//               // self.OrderDate = Date()
//
//                print("How many tickets do you want ? : ")
//                let qty : Int = (Int)(readLine()!) ?? 1
//
//                self.orderLists += [(flightId: selectedFlightID, flight: selectedFlight,  quantity: qty)]
//                self.resStatus = ResStatusList.Placed
//
//            }else{
//                print("Sorry...The flight you entered is unavailable")
//            }
            
            print("Enter passenger Id  : ")
            self.passengerId = readLine()!
            print("Enter passenger Passport Number : ")
            self.passengerPassportNumber = readLine()!
            print("Enter passenger Name  : ")
            self.passengerName = readLine()!
            print("Enter passenger Mobile : ")
            self.passengerMobile = Int(readLine()!)!
            print("Enter passenger Email : ")
            self.passengerEmail = readLine()!
            print("Enter passenger Address : ")
            self.passengerAddress = readLine()!
            print("enter flight id :")
            self.resFlightId = Int(readLine()!)
        }
    

    func addReservation(){
        print("Enter resID  : ")
         self.resID = Int(readLine()!)
        print("Enter resDesc : ")
        self.resDesc = readLine()!
        //print("Enter resFlightId  : ")
       // self.resFlightId = Int(readLine()!)
        print("Enter resSeatNumber : ")
         self.resSeatNumber = readLine()!
        //print("Enter resStatus : ")
       // self.resStatus = readLine()!
        print("Enter resMealType : ")
        self.resMealType = readLine()!
    }
    override func displayData() -> String {
        
        var returnData = ""
        
        if self.ResID != nil {
            returnData += "\n Reservation ID : " + String(self.resID!)
        }
        if self.ResDesc != nil {
            returnData += "\n Reservation Desc : " + self.resDesc!
        }
        if self.PassengerId != nil {
            returnData += "\n Passenger Id : " + String(self.passengerId)
        }
       
        if self.ResFlightId != nil {
            returnData += "\n Flight Id: " + String(self.resFlightId!)
        }
        if self.ResSeatNumber != nil {
            returnData += "\n Reservation Seat Number: " + String(self.resSeatNumber!)
        }
        if self.ResMealType != nil {
            returnData += "\n Reservation Meal Type : " + self.resMealType!
        }
        if self.passengerName != nil {
            returnData += "\n Passenger Name  : " + self.passengerName
        }
        if self.passengerAddress != nil {
            returnData += "\n Passenger Address : " + self.passengerAddress
        }
       
        
        if self.passengerPassportNumber != nil {
            returnData += "\n passenger Passport Number: " + String(self.passengerPassportNumber)
        }
        if self.passengerMobile != nil {
            returnData += "\n passenger Mobile: " + String(self.passengerMobile)
        }
        
        return returnData
        
    }
    
    
}
