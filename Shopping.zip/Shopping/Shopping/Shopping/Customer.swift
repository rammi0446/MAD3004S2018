//
//  Customer.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Customer : IDisplay
{
    var customerID : String?
   private var customerName : String?
   private var address : String?
   private var email : String?
   private var creditCardInfo : String?
   private var shippingInfo : String?
    //Stored property
    var CustomerName : String?
    {
        get{
            return self.customerName
        }
        set{
            self.customerName = newValue
        }
    }
    var Email : String?
    {
        get{
            return self.email
        }
        set{
            self.email = newValue
        }
    }
    var Address : String?
    {
        get{
            return self.address
        }
        set{
            self.address = newValue
        }
    }
    var CreditCardInfo : String?
    {
        get{
            return self.creditCardInfo
        }
        set{
            self.creditCardInfo = newValue
        }
    }
    var ShippingInfo : String?
    {
        get{
            return self.shippingInfo
        }
        set{
            self.shippingInfo = newValue
        }
    }
    
    //default constructor
    init() {
        self.customerName = ""
        self.address = ""
        self.email = ""
        self.creditCardInfo = ""
        self.shippingInfo = ""
    }
    //parameterize constructor
    init(customerID: String, customerName: String,email: String,address: String,creditCardInfo: String,shippingInfo: String) {
        self.customerID = customerID
        self.customerName = customerName
        self.email = email
        self.address = address
        self.creditCardInfo = creditCardInfo
        self.shippingInfo = shippingInfo
    }
    func displayData() -> String{
        var returnData = ""
        
        if self.customerID != nil{
            returnData += "\n customer id :" + self.customerID!
        }
        if self.customerName != nil {
            returnData += "\n customer name : " + self.customerName!
        }
        if self.email != nil{
            returnData += "\n customer email : " + self.email!
        }
        if self.address != nil{
            returnData += "\n customer address : " + self.address!
        }
        if self.creditCardInfo != nil{
            returnData += "\n customer credit card info :" + self.creditCardInfo!
        }
        if self.shippingInfo != nil{
            returnData += "\n shipping info :" + self.shippingInfo!
        }
        return returnData
    }
    func registerUser()
    {
        print("enter customer id :")
        self.customerID = readLine()!
        print("enter customer name :")
        self.customerName = readLine()!
        print("enter customer email :")
        self.email = readLine()!
        print("enter customer address :")
        self.address = readLine()!
        print("enter customer credit card info :")
        self.creditCardInfo = readLine()!
        print("enter customer shipping info :")
        self.shippingInfo = readLine()!
        
    }
}
