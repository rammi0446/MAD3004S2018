//
//  Product.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Product : IDisplay {
    private var productID : Int?
    private var productName : String?
    private var manufecturer : String?
    private var unitPrice : Double?
    private var category : ProductCategory?
    var ProductID : Int{
        get
        {
            return self.productID!
        }
        set{
            self.productID = newValue
        }
    }
    
    var ProductName : String?
    {
        get{
            return self.productName
        }
        set
        {
            self.productName = newValue
        }
    }
    
    var Manufecturer : String?
    {
        get
        {
            return self.manufecturer
        }set
        {
            self.manufecturer = newValue
        }
    }
    
    var UnitPrice : Double?
    {
        get
        {
            return self.unitPrice
        }set {
            self.unitPrice = newValue
        }
    }
    var Category : ProductCategory
    {
        get
        {
            return self.category!
        }set
        {
            self.category = newValue
        }
    }
    
    init()
    {
        self.productID = 0
        self.productName = ""
        self.manufecturer = ""
        self.unitPrice = 0
        self.category = ProductCategory.None
    }
    
    init(productID : Int, productName : String, manufecturer : String, unitPrice : Double, category: ProductCategory)
    {
        self.productID = productID
        self.productName = productName
        self.manufecturer = manufecturer
        self.unitPrice = unitPrice
        self.category = category
    }
    
    func displayData() -> String{
        var returnData = ""
        returnData += "\n Product id : \(self.productID  ?? 0)"
        returnData += "\n Product Name : \(self.productName ?? "")"
        returnData += "\n Manufecturer : \(self.manufecturer ?? "" )"
        returnData += "\n Unit Price : \(self.unitPrice ?? 0.0 )"
        returnData += "\n Category : \(self.category ?? ProductCategory.None)"
        return returnData
    }
    
    func newProduct() {
        print("enter product id ")
        self.productID = (Int)(readLine()!)!
        print("Enter product Name : ")
        self.productName = readLine()
        print("enter manufecturer :")
        self.manufecturer = readLine()
        print("please choose category")
        for category in ProductCategory.allCases
        {
            print("enter \(category.rawValue) for \(category)")
        }
        let choice = (Int) (readLine()!) ?? 5
        self.category = ProductCategory(rawValue: choice)
        print("enter unit price: ")
        self.unitPrice = (Double)(readLine()!)!
    }
    
}
