//
//  main.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var santosh = Customer()
santosh.customerID = "C101"
//santosh.customerName = "Santosh"
print(santosh.displayData())

var raman = Customer(customerID: "C102", customerName: "Raman", email: "raman@gmail.com", address:"5 Mast", creditCardInfo: "64765436468947513", shippingInfo: "ship to lambton college between 8.00 am to 12.00 pm")
print(raman.displayData())

var Saloni = Customer()
Saloni.registerUser()
print(Saloni.displayData())

santosh.CustomerName = "Santosh"
santosh.Email = "santosh@123"
santosh.Address = "Toronto"
santosh.CreditCardInfo = "6566676478"
santosh.ShippingInfo = "deliver to papa john at 3 pm"
print(santosh.displayData())
