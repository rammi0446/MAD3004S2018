//
//  Flight.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Flight{
    var flight_id : String?
    var flight_from : String?
    var flight_to : String?
    var flight_airline_id : Int
    var flight_airplane_id : String?
    var flight_pilot_id : String?
    
}
