//
//  Passenger.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Passenger {
    
    var passengerId : Int?
    var passengerPassportNumber : String?
    var passengerName : String?
    var passengerMobile : Int?
    var passengerEmail : String?
    var passengerAddress : String?
  //  var passengerBirthDate : Date?
    
//   let dateString = "12/12/1992"
//    let dateFormatter = DateFormatter()
//    dateFormatter.dateFormat = "yyyy'-'MM'-'dd'T'HH':'mm':'ssZZZ"
//    let date = dateFormatter.date(from: dateString)
//
   
    
    
    var PassengerId : Int? {
        get {
            return self.passengerId
        }
        set {
            self.passengerId = newValue
        }
    }
    
    var PassengerPassportNumber : String? {
        get {
            return self.passengerPassportNumber
        }
        set {
            self.passengerPassportNumber = newValue
        }
    }
    
    var PassengerName : String? {
        get {
            return self.passengerName
        }
        set {
            self.passengerName = newValue
        }
    }
    
    var PassengerMobile : Int? {
        get {
            return self.passengerMobile
        }
        set {
            self.passengerMobile = newValue
        }
    }
    
    var PassengerEmail : String? {
        get {
            return self.passengerEmail
        }
        set {
            self.passengerEmail = newValue
        }
    }
    
    var PassengerAddress : String? {
        get {
            return self.passengerAddress
        }
        set {
            self.passengerAddress = newValue
        }
    }
//    var PassengerBirthDate : Date? {
//        get {
//            return self.passengerBirthDate
//        }
//        set {
//            self.passengerBirthDate = newValue
//        }
//    }
//
    init() {
        self.passengerId = 0
        self.passengerPassportNumber = ""
        self.passengerName = ""
        self.passengerMobile = 0
        self.passengerEmail = ""
        self.passengerAddress = ""
       // self.passengerBirthDate = 29-01-1992
    }
    init(passengerId: Int,passengerPassportNumber: String,passengerName: String,PassengerMobile: Int,PassengerEmail: String, PassengerAddress: String)
    {
        self.passengerId = passengerId
        self.passengerPassportNumber = passengerPassportNumber
        self.passengerName = passengerName
        self.PassengerMobile = PassengerMobile
        self.passengerEmail = PassengerEmail
        
    }
    func displayData() -> String {
        
        var returnData = ""
        
        if self.passengerId != nil {
            returnData += "\n Passenger Id : " + String(self.passengerId!)
        }
        if self.passengerName != nil {
            returnData += "\n passengerName : " + self.passengerName!
        }
        if self.passengerPassportNumber != nil {
            returnData += "\n passengerPassportNumber : " + self.passengerPassportNumber!
        }
        //        if self.flightScheduleDate != nil {
        //            returnData += "\n Flight schedule : " + String(self.flightScheduleDate!)
        //        }
        if self.passengerMobile != nil {
            returnData += "\n passengerMobile: " + String(self.passengerMobile!)
        }
        if self.passengerEmail != nil {
            returnData += "\n passengerEmail: " + self.passengerEmail!
        }
        if self.passengerAddress != nil {
            returnData += "\n passengerAddress: " + String(self.passengerAddress!)
        }
        
        return returnData
        
    }
    
}
