//
//  Reservation.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Reservation {
    
    var resID : Int?
    var resDesc : String?
    var resPassengerId : Int?
    var resFlightId : Int?
   // var resDate : Date?
    var resSeatNumber : String?
    var resStatus : String?
    var resMealType : String?
    
    var ResID : Int?
    {
        get
        {
            return self.resID
        }
        set
        {
            self.resID = newValue
        }
    }
    var ResDesc : String?
    {
        get
        {
            return self.resDesc
        }
        set
        {
            self.resDesc = newValue
        }
    }
    var ResPassengerId : Int?
    {
        get
        {
            return self.resPassengerId
        }
        set
        {
            self.resPassengerId = newValue
        }
    }
    var ResFlightId : Int?
    {
        get
        {
            return self.resFlightId
        }
        set
        {
            self.resFlightId = newValue
        }
    }
//    var ResDate : Date?
//    {
//        get
//        {
//            return self.resDate
//        }
//        set
//        {
//            self.resDate = newValue
//        }
//    }
    var ResSeatNumber : String?
    {
        get
        {
            return self.resSeatNumber
        }
        set
        {
            self.resSeatNumber = newValue
        }
    }
    var ResStatus : String?
    {
        get
        {
            return self.resStatus
        }
        set
        {
            self.resStatus = newValue
        }
    }
    var ResMealType : String?
    {
        get
        {
            return self.resMealType
        }
        set
        {
            self.resMealType = newValue
        }
    }
    
    
    init() {
        self.resID = 0
        self.resDesc = ""
        self.resPassengerId = 0
        self.resFlightId = 0
       // self.resDate = 00/00/0000
        self.resSeatNumber = ""
        self.resStatus = ""
        self.resMealType = ""
    }
    
    init(resID : Int, resDesc : String, resPassengerId : Int, resFlightId : Int,/* resDate : Date ,*/ resSeatNumber : String, resStatus: String, resMealType: String) {
        
        self.resID = resID
        self.resDesc = resDesc
        self.resPassengerId = resPassengerId
        self.resFlightId = resFlightId
      //  self.resDate = resDate
        self.resSeatNumber = resSeatNumber
        self.resStatus = resStatus
        self.resMealType = resMealType
        
    }
    
    func displayData() -> String {
        
        var returnData = ""
        
        if self.ResID != nil {
            returnData += "\n resID : " + String(self.resID!)
        }
        if self.ResDesc != nil {
            returnData += "\n resDesc : " + self.resDesc!
        }
        if self.ResPassengerId != nil {
            returnData += "\n resPassengerId : " + String(self.resPassengerId!)
        }
        //        if self.flightScheduleDate != nil {
        //            returnData += "\n Flight schedule : " + String(self.flightScheduleDate!)
        //        }
        if self.ResFlightId != nil {
            returnData += "\n EmployeeMobile: " + String(self.resFlightId!)
        }
        if self.ResSeatNumber != nil {
            returnData += "\n resSeatNumber: " + String(self.resSeatNumber!)
        }
        if self.ResMealType != nil {
            returnData += "\n resMealType : " + self.resMealType!
        }
        
        return returnData
        
    }
    
    
}
