//
//  main.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation







var choice = Int()
var can = String()
var dataHelper = DataHelper()
var reservation = Reservation()
var res = Reservation()
while choice != 5{
    print("\n----What would you like to do today !----")
    print("\t 1 : Display List ")
    print("\t 2 : Add Passenger ")
    print("\t 3 : Show Booking ")
    print("\t 4 : Cancel Booking ")
   
    print("\t 5 : Exit ")
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!
    
    
//    func cancelFlight() {
//        
////    print("To cancel your flight press Y")
////        can = (readLine()!)
////
////        if can == "Y" {
//            res.displayData()
////        } else {
////            print("You have not entered valid option")
////        }
//        
//    }
    
    switch choice{
    case 1:
        dataHelper.displayLists()
    case 2:
        print("ENTER PASSENGER DETAILS \n")
        res.addPassenger()
        print("\nENTER RESERVATION DETAILS \n")
        res.addReservation()
    case 3:
     print(res.displayData())
     
     
      switch savedFlightId{
      case 111:
        print(" Flight id : 111 \n" + " Flight From : India \n" + "Flight To : Toronto \n" )
      case 112:
        print(" Flight id : 112 \n" + " Flight From : India \n" + "Flight To : London \n")
      case 113:
        print(" Flight id : 113 \n" + " Flight From : Toronto \n" + "Flight To : UK \n")
      case 114:
        print(" Flight id : 114 \n" + " Flight From : USA \n" + "Flight To : Canada \n")
      case 115:
        print(" Flight id : 115 \n" + " Flight From : UK \n" + "Flight To : USA \n")
      default:
        print("end")

        }
        
    case 4:
        if savedFlightId != nil {
            print(res.displayData())
            print("\n Flight is successfully cancelled")
            
        }
        else{
            print("please add passenger details and select flight first")
        }
        
    case 6:
        exit(0)
    default:
        print("Please enter valid menu option.")
    }
    
   
    
    
}



