//
//  Airlines.swift
//  AirTicket
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Airlines {
    
    // MARK:- Variables
    
    var enquiryID : Int?
    var enquiryType : String?
    var enquiryTitle : String?
    var enquiryDescription : String?
    
    var EnquiryID : Int? {
        get {
            return self.enquiryID
        }
        set {
            self.enquiryID = newValue
        }
    }
    
    var EnquiryType : String? {
        get {
            return self.enquiryType
        }
        set {
            self.enquiryType = newValue
        }
    }
    
    var EnquiryTitle : String? {
        get {
            return self.enquiryTitle
        }
        set {
            self.enquiryType = newValue
        }
    }
    
    var EnquiryDescription : String? {
        get {
            return self.enquiryDescription
        }
        set {
            self.enquiryDescription = newValue
        }
    }
    
    // MARK:- Initializer
    
    init() {
        self.enquiryID = 0
        self.enquiryType = ""
        self.enquiryTitle = ""
        self.enquiryDescription = ""
    }
    
    init(enquiryID : Int, enquiryType : String, enquiryTitle : String, enquiryDescription : String) {
        self.enquiryID = enquiryID
        self.enquiryType = enquiryType
        self.enquiryTitle = enquiryTitle
        self.enquiryDescription = enquiryDescription
    }
    
    //MARK:- Display data
    
    func displayAirline() -> String {
        var returnData = ""
        
        if self.EnquiryID != nil {
            returnData += "\n Enquiry ID : " + String(self.enquiryID!)
        }
        if self.EnquiryType != nil {
            returnData += "\n Enquiry type : " + self.enquiryType!
        }
        if self.EnquiryTitle != nil {
            returnData += "\n Enquiry title : " + self.enquiryTitle!
        }
        if self.EnquiryDescription != nil {
            returnData += "\n Enquiry description : " + self.enquiryDescription!
        }
        return returnData
    }
    
}


