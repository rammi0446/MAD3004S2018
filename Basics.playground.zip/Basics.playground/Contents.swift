//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground";

print("Hello");

print("Hello Friends","Hallo Friends",str,separator:"Next..")

print(1,2,3,4,5,separator: "....", terminator: "The end ")

var num1=10
var num2=20
let sum=num1+num2

print(" sum of \(num1) and \(num2) is \(sum)")

print("🐥","🐤",separator: "🇧🇴")

var x: Int
x = 10
print("values of \(x)")

var greet:String?
print("Hello, \(String(describing: greet))")


 greet = "Welcome"
print("hello, \(String(describing: greet))")

if greet != nil{
    print(greet!)
}
else{
    print("greet is nil")
}

var temerature : Int!

print(temerature)

if(temerature != nil)
{
    print("\(temerature) is not nil")
    
}
else{
    print("temprature is nil")
}


let PI:Float=3.142
print("Pi = \(PI)")

let friends:[String] = ["LA","Abhi","Akash","Aman"]

for frdn in friends{
    print("\(frdn)")
}

var j = 1
while (j<3) {
    
    print("\(j)")
    j = j+1;
}

let coordinate = (10,20)
switch coordinate
{
case(0,0):
    print(" no canvas ")
    fallthrough
case(_,20):
    print("y axis")
    fallthrough
case(10,_):
    print("x axis")
    fallthrough
case(1...10,1...20):
    print("within canvas")
default:
    print("canvas unavilable")
}

let range = 1...5
print(range)
print("\(range) contains 3 : ",range.contains(3))
print("\(range) contains 7 : ",range.contains(7))
print("\(range) lowerbound : ",range.lowerBound)
print("\(range) upperbound : ",range.upperBound)

