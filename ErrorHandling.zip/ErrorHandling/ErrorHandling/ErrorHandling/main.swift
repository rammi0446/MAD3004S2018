//
//  main.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var request1 = RequestLimitIncrease()

//do{
//try request1.increaseLimit(accountNo: "S1100")
//}catch limitIncreaseError.ineligible{
//    print("you must have account with our bank")
//}catch limitIncreaseError.noSavingAccount{
//    print("sorry.. Limit increase is provided only to the Saving Account Holders")
//}catch limitIncreaseError.insufficientBalance{
//    print("Minimum $5000 balance is required for credit limit increase.")
//}catch{
//    print("something unexpected happen.. Sorry for the service disrupton")
//}

do{
    try request1.increaseLimit(accountNo: "S1300")
}catch is limitIncreaseError{
    print("You do not match any of the following criteria for credit limit increase")
    print("1. no account with oour bank \n2. No Saving account \n3. InSufficient balance in saving account (minimum $5000)")
    
}

var s1 = Student()
s1.name = "JK"
Student.accNo = 123456
s1.display()

var s2 = Student()
print("Student count : \(Student.getStudentCount())")

print("account no : \(Student.accNo!)")

var s3 = PartTime()
s3.display()
print(PartTime.getStudentCount())

var s4 = Student()
s4.name = "Gurjot"
s4.display()

s4 = PartTime()
s4.display()

s1 = s4 as! PartTime
s1.display()
