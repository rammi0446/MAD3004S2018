//
//  PermanentEmployee.swift
//  Day7
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class PermanentEmployee : Employee, INetPayCalculation
{
    var netPAy: Double?
    
    var vacationWeek : Int?
    
    //read only property
    var netPay : Double? {
        get{
            if self.vacationWeek! > 3
            {
                return self.basicPay! - 100
            }
            else
            {
                return self.basicPay!
            }
        }
        
    }
    
    override required init() {
       
        self.vacationWeek = 0
         super.init()
    }
    
    init(empID: Int, empName: String, basicPay: Double,holiday: Int) {
       super.init(empID: empID, empName: empName, basicPay: basicPay)
        self.vacationWeek = holiday
    }
    
    override func display() {
        super.display()
        print("vacation weeks : \(self.vacationWeek ?? 0)")
        print("net pay : \(self.netPay?.asCurrency  ?? self.basicPay?.asCurrency  ?? 0.0.asCurrency)")
    }
}
